-- Character associations UI. Changes save immediately; opinion drafts stay intact.
local Addon = Raidwise
local W = Addon.Widgets
local UI = Addon.UITheme
local ROW_HEIGHT = 28
local AttemptLink
local CurrentGuid

local function FinishAction(frame, ok, message)
	local member = frame.profileMember
	if member then frame.profileMember = Addon:HistoryProfileForMember(member) end
	Addon:RefreshProfileCharacters(frame)
	frame.charactersStatus:SetText(W.T(ok and "CHAR_LINK_SAVED" or (message or "CHAR_LINK_INVALID")))
	if Addon.RefreshLinkedProfileOpinion then Addon:RefreshLinkedProfileOpinion(frame) end
	if Addon.RefreshRatingViews then Addon:RefreshRatingViews() end
end

AttemptLink = function(frame, otherGuid, seed)
 local ok, message = Addon:LinkPlayerCharacters(CurrentGuid(frame), otherGuid, seed)
 FinishAction(frame, ok, message)
end

CurrentGuid = function(frame)
	local member = frame.profileMember
	if not member or not member.guid or member.guid == "" then return nil end
	Addon:EnsureHistoryEntryForGuid(member.guid, member)
	return member.guid
end

local function CreateList(parent, name, height)
	local scroll = CreateFrame("ScrollFrame", name, parent, "UIPanelScrollFrameTemplate")
	scroll:SetHeight(height)
	local content = CreateFrame("Frame", nil, scroll)
	content:SetHeight(1)
	scroll:SetScrollChild(content)
	return scroll, content
end

local function CreateCharacterRow(parent, candidate)
	local row = CreateFrame("Frame", nil, parent)
	row:SetHeight(ROW_HEIGHT)
	row.name = W.CreateFontString(row, nil, "OVERLAY", "GameFontHighlightSmall")
	row.name:SetPoint("LEFT", 0, 0)
	row.name:SetJustifyH("LEFT")
	row.buttons = {}
	local keys = candidate and { "CHAR_LINK_ADD" } or { "OPEN_PROFILE", "CHAR_ROLE_MAIN", "CHAR_LINK_REMOVE" }
	local previous
	for index = #keys, 1, -1 do
		local key = keys[index]
		local button = W.CreatePlainButton(row, key == "OPEN_PROFILE" and 85 or 70, 22, key == "OPEN_PROFILE" and (Addon.db.locale == "ruRU" and "Профиль" or "Profile") or W.T(key))
		if previous then button:SetPoint("RIGHT", previous, "LEFT", -3, 0)
		else button:SetPoint("RIGHT", row, "RIGHT", 0, 0) end
		row.buttons[key] = button
		previous = button
	end
	row.name:SetPoint("RIGHT", previous, "LEFT", -6, 0)
	return row
end

local function FillRows(frame, content, rows, characters, candidate)
	for _, row in ipairs(rows) do row:Hide() end
	local guid = frame.profileMember and frame.profileMember.guid
	for index, character in ipairs(characters) do
		local entry = candidate and character or character.entry
		local row = rows[index]
		if not row then row = CreateCharacterRow(content, candidate); rows[index] = row end
		for _, button in pairs(row.buttons) do button:Enable() end
		row:SetPoint("TOPLEFT", 0, -(index - 1) * ROW_HEIGHT)
		row:SetPoint("RIGHT", content, "RIGHT", 0, 0)
		local label = Addon:LinkedCharacterName(entry)
		if not candidate then label = label .. " (" .. W.T("CHAR_ROLE_" .. string.upper(character.role)) .. ")" end
		row.name:SetText(label)
		local color = RAID_CLASS_COLORS and RAID_CLASS_COLORS[entry.class]
		W.SetFontColor(row.name, color and { color.r, color.g, color.b } or UI.TEXT_IDLE)
		row:SetScript("OnEnter", function()
			GameTooltip:SetOwner(row, "ANCHOR_RIGHT")
			GameTooltip:AddLine(Addon:LinkedCharacterName(entry))
			GameTooltip:AddLine(entry.guid or "", 0.7, 0.7, 0.7)
			if not candidate then GameTooltip:AddLine(W.T("CHAR_ROLE_" .. string.upper(character.role))) end
			GameTooltip:Show()
		end)
		row:SetScript("OnLeave", function() GameTooltip:Hide() end)
		row:EnableMouse(true)
		if candidate then
			local button = row.buttons.CHAR_LINK_ADD
			button.label:SetText(W.T("CHAR_LINK_ADD"))
			button:SetScript("OnClick", function()
				AttemptLink(frame, entry.guid)
			end)
		else
			local open = row.buttons.OPEN_PROFILE
			open.label:SetText(Addon.db.locale == "ruRU" and "Профиль" or "Profile")
			open:SetScript("OnClick", function() Addon:ShowRaidCharacterWindow(entry) end)
			for _, role in ipairs({ "main" }) do
				local button = row.buttons["CHAR_ROLE_" .. string.upper(role)]
				button.label:SetText(W.T("CHAR_ROLE_" .. string.upper(role)))
				W.SetMenuButtonState(button, character.role == role, false)
				button:SetScript("OnClick", function()
					FinishAction(frame, Addon:SetLinkedCharacterRole(CurrentGuid(frame), entry.guid, role))
				end)
			end
			local remove = row.buttons.CHAR_LINK_REMOVE
			remove.label:SetText(W.T("CHAR_LINK_REMOVE"))
			if #characters > 1 and character.role ~= "main" then remove:Enable() else remove:Disable() end
			remove:SetScript("OnClick", function()
				FinishAction(frame, Addon:UnlinkPlayerCharacter(guid, entry.guid))
			end)
		end
		row:Show()
	end
	content:SetHeight(math.max(1, #characters * ROW_HEIGHT))
end

function Addon:RefreshProfileCharacters(frame)
	if not frame or not frame.charactersContent then return end
	local guid = frame.profileMember and frame.profileMember.guid
	frame.charactersHint:SetText(Addon.db.locale == "ruRU" and "Мнение и заметка у каждого персонажа свои. Связи сохраняются сразу."
		or "Each character has their own opinion and note. Links save immediately.")
	frame.characterSearchToggle.label:SetText(Addon.db.locale == "ruRU" and "Связать персонажа" or "Link character")
	frame.charactersLinkedScroll:SetHeight(frame.characterSearchPanel:IsShown() and 80 or math.max(84, frame.profilePanels.characters:GetHeight() - 76))
	frame.charactersSearchLabel:SetText(W.T("CHAR_LINK_SEARCH"))
	frame.charactersTarget.label:SetText(W.T("CHAR_LINK_TARGET"))
	frame.charactersStatus:SetText("")
	local linked = self:GetLinkedCharacters(guid)
	if #linked == 0 and guid and guid ~= "" then
		linked = { { guid = guid, entry = frame.profileMember, role = "main" } }
	end
	FillRows(frame, frame.charactersContent, frame.characterRows, linked, false)
	FillRows(frame, frame.characterCandidatesContent, frame.characterCandidateRows,
		frame.characterSearchPanel:IsShown() and guid and guid ~= "" and self:GetCharacterLinkCandidates(guid, frame.charactersSearch:GetText()) or {}, true)
	if guid and guid ~= "" then frame.charactersTarget:Enable() else frame.charactersTarget:Disable() end
end

function Addon:CreateProfileCharactersPanel(frame, parent, width, layoutVersion)
	local panel = parent
	panel:Hide()
	frame.profilePanels.characters = panel
	local hint = W.CreateFontString(panel, nil, "OVERLAY", "GameFontNormalSmall")
	hint:SetPoint("TOPLEFT", 0, 0)
	hint:SetWidth(width - 220)
	hint:SetHeight(30)
	hint:SetJustifyH("LEFT")
	frame.charactersHint = hint
	local toggle = W.CreatePlainButton(panel, 200, 24, "")
	toggle:SetPoint("TOPRIGHT", 0, 0); frame.characterSearchToggle = toggle
	local searchPanel = CreateFrame("Frame", nil, panel)
	searchPanel:SetPoint("TOPLEFT", 0, -120); searchPanel:SetPoint("BOTTOMRIGHT", 0, 32)
	frame.characterSearchPanel = searchPanel
	toggle:SetScript("OnClick", function()
		if searchPanel:IsShown() then searchPanel:Hide() else searchPanel:Show() end
		Addon:RefreshProfileCharacters(frame)
	end)
	searchPanel:Hide()
	local linkedScroll, linkedContent = CreateList(panel, "RaidwiseLinkedCharactersV" .. layoutVersion, 84)
	linkedScroll:SetPoint("TOPLEFT", hint, "BOTTOMLEFT", 0, -4)
	linkedScroll:SetPoint("RIGHT", panel, "RIGHT", -24, 0)
	linkedContent:SetWidth(width - 28)
	frame.charactersContent, frame.characterRows = linkedContent, {}
	frame.charactersLinkedScroll = linkedScroll
	local searchLabel = W.CreateFontString(searchPanel, nil, "OVERLAY", "GameFontNormalSmall")
	searchLabel:SetPoint("TOPLEFT", 0, 0)
	frame.charactersSearchLabel = searchLabel
	local target = W.CreatePlainButton(searchPanel, 120, 24, "")
	local search, searchHost = W.CreateTextInput(searchPanel, width - 128)
	searchHost:SetPoint("TOPLEFT", searchLabel, "BOTTOMLEFT", 0, -4)
	searchHost:SetPoint("RIGHT", target, "LEFT", -8, 0)
	target:ClearAllPoints()
	target:SetPoint("RIGHT", searchPanel, "RIGHT", 0, 0)
	target:SetPoint("TOP", searchLabel, "BOTTOM", 0, -4)
	search:SetScript("OnTextChanged", function() Addon:RefreshProfileCharacters(frame) end)
	frame.charactersSearch, frame.charactersTarget = search, target
	target:SetScript("OnClick", function()
		if not UnitExists("target") or not UnitIsPlayer("target") then
			FinishAction(frame, false, "CHAR_LINK_TARGET_MISSING"); return
		end
		local guid = UnitGUID("target")
		local name, realm = UnitName("target")
		local classLabel, class = UnitClass("target")
		AttemptLink(frame, guid, {
			guid = guid, name = name, realm = realm or GetRealmName(), class = class, classLabel = classLabel,
		})
	end)
	local status = W.CreateFontString(panel, nil, "OVERLAY", "GameFontNormalSmall")
	status:SetPoint("BOTTOMLEFT", 0, 0)
	status:SetPoint("RIGHT", panel, "RIGHT", 0, 0)
	status:SetHeight(32)
	status:SetJustifyH("LEFT")
	status:SetJustifyV("TOP")
	frame.charactersStatus = status

	local candidatesScroll, candidatesContent = CreateList(searchPanel, "RaidwiseCharacterCandidatesV" .. layoutVersion, 1)
	candidatesScroll:SetPoint("TOPLEFT", searchHost, "BOTTOMLEFT", 0, -6)
	candidatesScroll:SetPoint("BOTTOMRIGHT", searchPanel, "BOTTOMRIGHT", -24, 0)
	candidatesContent:SetWidth(width - 28)
	frame.characterCandidatesContent, frame.characterCandidateRows = candidatesContent, {}
end
